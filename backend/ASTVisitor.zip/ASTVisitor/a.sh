make
cd build
./myASTVisitor $1.cpp
cd ..
