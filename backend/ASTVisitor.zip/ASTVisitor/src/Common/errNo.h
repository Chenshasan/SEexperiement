#pragma once
enum{
    ArrayOutOfBound,
    SlowMemoryOper,
    SwitchMismatch,
    SpaceProblem,
    NullDeref,
    DoubleFree
};